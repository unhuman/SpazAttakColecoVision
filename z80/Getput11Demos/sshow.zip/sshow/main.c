/****************************************************************************/
/**                                                                        **/
/**                                  main.c                                **/
/**                                                                        **/
/**                            SIMPLE IMAGE TEST                           **/
/**                        Par / by Daniel Bienvenu                        **/
/**                                                                        **/
/**                                  2001(c)                               **/
/****************************************************************************/

#include "coleco.h"
#include "getput1.h"

/* various RLE-encoded tables (in tables.c) */
extern byte unicorn[];
extern byte autopsy[];

/* The NMI routine */
void nmi (void)
{
 update_sound();
}

static byte ding3_sound[] = {0, 0x63,0xf,1,
  0x80,0xe0,0x95,1, 0x80,0x96,0x90,1, 0x80,0x4a,0x96,1,
  0x80,0x74,0x95,2, 0x82,0x91,0x94,1, 0x81,0x2e,1, 0x80,0x9d,1,
  0x80,0x72,0x95,1, 0x80,0x4a,0x97,1, 0x80,0xde,2, 
  0x81,0x2f,0x97,1, 0x80,0xd1,1, 0x80,0x96,1, 0x80,0x50,0x99,1,
  0x80,0x5f,0x99,2, 0x82,0x49,1, 0x81,0x2f,1, 0x80,0xa1,1,
  0x80,0x77,0x9a,1, 0x80,0x4a,0x9b,1, 0x80,0xc2,2,
  0x81,0xee,0x9b,1, 0x81,0x24,1, 0x80,0x96,0x9c,1, 0x80,0x6a,1,
  0x80,0x49,1, 0x81,0x66,2, 0x81,0x2e,0x9d,1, 0x81,0xdc,1,
  0x81,0x15,0x9e,1, 0x80,0x8c,1, 0x80,0x61,1, 
 0,0,0 };

static void ding3 (void)
{
 start_sound (ding3_sound,7);
 delay(37);
}

void main (void)
{
 /* initialize VDP */
 screen_mode_2_bitmap();
 /* Clear Sprites */
 clear_sprites (0,64);
 update_sprites(32,sprgen);

recomm:
 /* show picture #1 */
 show_picture (unicorn); 
 delay(10);
 ding3();
 pause();

 /* show picture #2 */
 show_picture (autopsy); 
 delay(10);
 ding3();
 pause();

 goto recomm; 
}
