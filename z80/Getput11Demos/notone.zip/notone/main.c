#include <coleco.h>

void nmi(void)
{
	update_sound();
}

void main(void)
{
	init_vdp();
	title_screen();
	game();
}