#include <coleco.h>
#include <getput1.h>

extern char GAME_NAME[];
extern char GAME_AUTHOR[];
extern char GAME_YEAR[];

void title_screen(void)
{
	cls();
	center_string(1,"COLECOVISION");
	center_string(4,"PRESENTS");
	center_string(10,GAME_NAME);
	center_string(14,"BY");
	center_string(16,GAME_AUTHOR);
	center_string(20,GAME_YEAR);
	center_string(23,"PRESS FIRE");
	pause();
}