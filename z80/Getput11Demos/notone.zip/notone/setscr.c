#include <coleco.h>
#include <getput1.h>

void setup_screen(void)
{
	screen_mode_2_text();
	upload_default_ascii(BOLD);
	fill_vram(0x2000,0xf0,0x0800);
}
