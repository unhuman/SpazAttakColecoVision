#define NO_SPRITES
