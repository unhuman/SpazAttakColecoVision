#include <coleco.h>
#include <graphics.h>

#ifdef NO_GRAPHICS
#define NO_SPRITES
#endif

#ifndef NO_GRAPHICS
extern byte PATTERNRLE[];
extern byte COLORRLE[];
#endif

#ifndef NO_SPRITES
extern byte SPATTERNRLE[];
#endif

void init_vdp(void)
{
	setup_screen();

#ifndef NO_GRAPHICS
	rle2vram(PATTERNRLE,0x0400);
	rle2vram(COLORRLE,0x2400);
#endif

#ifndef NO_SPRITES
	rle2vram(SPATTERNRLE,0x3800);
#endif
}
